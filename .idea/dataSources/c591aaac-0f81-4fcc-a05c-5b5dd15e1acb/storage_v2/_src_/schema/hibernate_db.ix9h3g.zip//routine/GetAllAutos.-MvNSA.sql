create
    definer = root@localhost procedure GetAllAutos()
BEGIN
	select * from auto;
END;

