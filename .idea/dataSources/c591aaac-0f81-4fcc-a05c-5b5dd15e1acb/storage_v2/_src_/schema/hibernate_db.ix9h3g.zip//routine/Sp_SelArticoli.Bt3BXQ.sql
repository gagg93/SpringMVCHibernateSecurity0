create
    definer = root@localhost procedure Sp_SelArticoli()
BEGIN

 SELECT * FROM hibernate_db.Auto;

END;

