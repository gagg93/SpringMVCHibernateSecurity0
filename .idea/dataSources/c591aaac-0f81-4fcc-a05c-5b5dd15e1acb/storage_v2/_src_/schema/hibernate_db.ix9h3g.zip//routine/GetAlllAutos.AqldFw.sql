create
    definer = root@localhost procedure GetAlllAutos()
BEGIN
	select * from hibernate_db.auto;
END;

